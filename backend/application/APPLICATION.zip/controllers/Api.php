<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Booking API — public REST API
 *
 * Routes (defined in application/config/routes.php):
 *   GET  /api/fleet                       → list vehicles
 *   GET  /api/settings                    → global settings (Meet & Greet fees)
 *   POST /api/reservation                 → create booking (returns booking_id)
 *   GET  /api/reservation/:id             → fetch booking detail
 *   POST /api/paypal/create-order         → open a PayPal order, returns the approval redirect URL
 *   GET  /api/paypal/return               → PayPal redirects here after the customer approves
 *   GET  /api/paypal/cancel               → PayPal redirects here if the customer cancels
 *   GET  /api/health                      → health check
 *
 * Payment is a redirect checkout (PayPal Orders v2 REST API): the widget
 * calls paypal_create_order(), sends the browser to the approval link
 * PayPal returns, and PayPal redirects back to paypal_return() once the
 * customer approves — that's where the hold is actually placed. An admin
 * must still accept the reservation (see Admin_api::reservations_accept)
 * before the held funds are captured. See
 * backend/application/libraries/Paypal.php.
 *
 * CORS: open by default (set $allowed_origins in __construct to lock down).
 */

class Api extends CI_Controller
{
    /** Comma-separated list of allowed origins, or ['*'] for any. */
    protected $allowed_origins = ['*'];

    public function __construct()
    {
        parent::__construct();
        $this->load->model(['Booking_model', 'Promo_model', 'Addon_model', 'Customer_model', 'Settings_model']);
        $this->load->library(['paypal', 'flights']);
        $this->_set_cors_headers();
    }

    // ----------------- ROUTES -----------------

    public function fleet()
    {
        $this->_json($this->Booking_model->get_fleet());
    }

    /**
     * GET /api/settings
     * Public global settings the widget needs before a vehicle is picked —
     * currently just the Meet & Greet fee (Chicago vs. all other airports).
     */
    public function settings()
    {
        $this->_json(array_merge(['success' => TRUE], $this->Settings_model->meet_greet_fees()));
    }

    public function health()
    {
        $this->_json([
            'ok'    => TRUE,
            'env'   => ENVIRONMENT,
            'time'  => date('c'),
            'php'   => PHP_VERSION,
        ]);
    }

    /** POST /api/reservation  { ...ride fields, vehicle, amount, customer } */
    public function reservation_create()
    {
        $raw = $this->_read_json();
        if (!$raw) return $this->_error('Invalid JSON body', 400);

        $required = ['service', 'pickupDate', 'pickupTime', 'pickup',
                     'passengers', 'vehicle_id', 'amount',
                     'firstName', 'lastName', 'email', 'phone'];
        foreach ($required as $field) {
            if (!isset($raw[$field]) || $raw[$field] === '') {
                return $this->_error("Missing field: $field", 422);
            }
        }
        // dropoff can be missing if "return at same location" — fall back to pickup
        if (empty($raw['dropoff'])) $raw['dropoff'] = $raw['pickup'];
        if (!filter_var($raw['email'], FILTER_VALIDATE_EMAIL)) {
            return $this->_error('Invalid email address', 422);
        }

        $booking_id = $this->Booking_model->create_booking($raw);

        // Auto-link to a customer record (creates one if new)
        if (!empty($raw['email'])) {
            $customerId = $this->Customer_model->upsert_from_booking([
                'email'      => $raw['email'],
                'first_name' => $raw['firstName'] ?? '',
                'last_name'  => $raw['lastName']  ?? '',
                'phone'      => $raw['phone']      ?? '',
            ]);
            if ($customerId) {
                $this->db->where('booking_id', $booking_id)->update('kfb_bookings', ['customer_id' => $customerId]);
            }
        }

        $this->_json([
            'success'    => TRUE,
            'booking_id' => $booking_id,
            'status'     => 'pending',
        ], 201);
    }

    /** GET /api/reservation/:id */
    public function reservation_get($id = NULL)
    {
        if (!$id) return $this->_error('Booking ID required', 400);
        $row = $this->Booking_model->get_booking($id);
        if (!$row) return $this->_error('Booking not found', 404);
        $this->_json($row);
    }

    /**
     * POST /api/paypal/create-order
     * Body: { booking_id, amount, return_url, cancel_url }
     * Opens a PayPal order (intent=AUTHORIZE — nothing is held or charged
     * yet) and returns the URL to redirect the customer's browser to so
     * they can approve it on paypal.com. return_url/cancel_url are
     * supplied by the widget (its own current page, so it can bring the
     * customer back to the right place) — PayPal appends its own
     * ?token=&PayerID= to return_url when it redirects back.
     */
    public function paypal_create_order()
    {
        $raw = $this->_read_json();
        if (!$raw) return $this->_error('Invalid JSON body', 400);

        $bookingId = trim((string)($raw['booking_id'] ?? ''));
        $amount    = $raw['amount'] ?? NULL;
        $returnUrl = trim((string)($raw['return_url'] ?? ''));
        $cancelUrl = trim((string)($raw['cancel_url'] ?? ''));
        if ($bookingId === '' || !$amount) {
            return $this->_error('booking_id and amount are required', 422);
        }
        if (!preg_match('#^https?://#i', $returnUrl) || !preg_match('#^https?://#i', $cancelUrl)) {
            return $this->_error('return_url and cancel_url must be absolute http(s) URLs', 422);
        }

        $booking = $this->db->get_where('kfb_bookings', ['booking_id' => $bookingId])->row_array();
        if (!$booking) return $this->_error('Booking not found', 404);

        try {
            $order = $this->paypal->createOrder($amount, $bookingId, $returnUrl, $cancelUrl);
        } catch (Exception $e) {
            log_message('error', '[PayPal] create-order failed for ' . $bookingId . ': ' . $e->getMessage());
            return $this->_error('Could not start PayPal checkout', 502, ['detail' => $e->getMessage()]);
        }

        $approveUrl = $this->paypal->approveLink($order);
        if (empty($order['id']) || !$approveUrl) {
            log_message('error', '[PayPal] create-order for ' . $bookingId . ' had no approval link: ' . json_encode($order));
            return $this->_error('PayPal did not return an approval link', 502);
        }

        $this->Booking_model->save_paypal_order($bookingId, $order['id']);

        $this->_json(['success' => TRUE, 'booking_id' => $bookingId, 'approve_url' => $approveUrl]);
    }

    /**
     * GET /api/paypal/return
     * Query: token (PayPal order id), PayerID, booking_id, site_return
     * (the widget's own page — where we send the browser back to).
     * Places the authorization hold now that the customer has approved,
     * then redirects into the widget's page with a ?kfb_paypal= status
     * flag so it can show a result without needing the lost form state.
     */
    public function paypal_return()
    {
        $token      = trim((string)($this->input->get('token') ?? ''));
        $bookingId  = trim((string)($this->input->get('booking_id') ?? ''));
        $siteReturn = (string)($this->input->get('site_return') ?? '');

        $booking = $bookingId !== '' ? $this->db->get_where('kfb_bookings', ['booking_id' => $bookingId])->row_array() : NULL;

        // The order id PayPal sends back must match the one we created for
        // this booking — otherwise this callback isn't trustworthy.
        if (!$booking || $token === '' || empty($booking['paypal_order_id']) || !hash_equals($booking['paypal_order_id'], $token)) {
            log_message('error', '[PayPal] return callback token mismatch for booking ' . $bookingId);
            return $this->_redirect_to_site($siteReturn, $bookingId, 'error', 'Invalid PayPal return');
        }

        try {
            $result = $this->paypal->authorizeOrder($token);
        } catch (Exception $e) {
            log_message('error', '[PayPal] authorizeOrder failed for ' . $bookingId . ': ' . $e->getMessage());
            return $this->_redirect_to_site($siteReturn, $bookingId, 'error', 'Payment could not be authorized');
        }

        $this->Booking_model->save_paypal_auth($bookingId, [
            'paypal_auth_transaction_id' => $result['TRANSACTIONID'] ?? NULL,
            'card_brand'                 => NULL,
            'card_last4'                 => NULL,
        ]);
        $this->Booking_model->record_payment($bookingId, $result['TRANSACTIONID'] ?? NULL, 'authorize', $result['ACK'] ?? 'Success', [
            'amount'   => $booking['amount'],
            'currency' => 'USD',
            'result'   => $result,
        ]);

        $this->_redirect_to_site($siteReturn, $bookingId, 'success', '');
    }

    /** GET /api/paypal/cancel — the customer backed out of the PayPal approval page. */
    public function paypal_cancel()
    {
        $bookingId  = trim((string)($this->input->get('booking_id') ?? ''));
        $siteReturn = (string)($this->input->get('site_return') ?? '');
        $this->_redirect_to_site($siteReturn, $bookingId, 'cancelled', '');
    }

    /**
     * Send the browser back into the widget's own page with a status
     * flag. $siteReturn is client-supplied, so it's restricted to
     * http(s) (never javascript:/data: etc.) — this is a public,
     * unauthenticated endpoint either way, same trust level as the rest
     * of this controller.
     */
    protected function _redirect_to_site($siteReturn, $bookingId, $status, $message)
    {
        if (!preg_match('#^https?://#i', $siteReturn)) {
            $siteReturn = '/';
        }
        $sep = (strpos($siteReturn, '?') === FALSE) ? '?' : '&';
        $url = $siteReturn . $sep . 'kfb_paypal=' . rawurlencode($status) . '&booking_id=' . rawurlencode((string)$bookingId);
        if ($message !== '') $url .= '&kfb_paypal_message=' . rawurlencode($message);
        header('Location: ' . $url, TRUE, 302);
        exit;
    }

    /**
     * GET /api/promo/validate?code=XYZ&amount=189.50
     * Returns { ok, code, discount, final, reason, description } so the
     * embed widget can display the discount before sending the booking.
     */
    public function promo_validate()
    {
        $code   = trim((string)($this->input->get('code') ?? ''));
        $amount = (float)($this->input->get('amount') ?? 0);
        if ($code === '') {
            return $this->_error('Promo code is required', 422);
        }
        $result = $this->Promo_model->validate($code, $amount);
        $this->_json(array_merge(['success' => TRUE], $result));
    }

    /**
     * GET /api/addons?region=chicago|america|worldwide
     * Returns enabled add-ons with the correct unit price for the
     * customer's detected region.
     */
    public function addons()
    {
        $region = strtolower((string)($this->input->get('region') ?? 'worldwide'));
        if (!in_array($region, ['chicago', 'america', 'worldwide'], TRUE)) $region = 'worldwide';
        $rows = $this->Addon_model->list_all(TRUE);
        $out = array_map(function ($a) use ($region) {
            $unit = $this->Addon_model->price_for_region($a, $region);
            return [
                'id'         => (int)$a['id'],
                'code'       => $a['code'],
                'name'       => $a['name'],
                'description'=> $a['description'],
                'category'   => $a['category'],
                'pricing_type'=> $a['pricing_type'],
                'unit_price' => $unit,
                'region'     => $region,
            ];
        }, $rows);
        $this->_json(['success' => TRUE, 'addons' => $out, 'region' => $region]);
    }

    /**
     * GET /api/flights/validate?flight=AA1234&date=2026-08-01
     * Looks up a real flight via the configured provider (Aviationstack
     * by default). On API error or no key configured, returns ok=false
     * with reason="unavailable" so the frontend can fall back to
     * manual entry without blocking the user.
     */
    public function flights_validate()
    {
        $flight = strtoupper(trim((string)($this->input->get('flight') ?? '')));
        $date   = trim((string)($this->input->get('date')   ?? ''));
        if ($flight === '' || $date === '') {
            return $this->_error('flight and date query params are required', 422);
        }
        $result = $this->flights->lookup($flight, $date);
        // Always return 200 with ok=false on "not found" so the frontend
        // can cleanly fall back to manual entry without treating it as
        // a server error.
        $this->_json(array_merge(['success' => TRUE], $result));
    }

    /**
     * POST /api/reservation/sign
     * Body: { booking_id, signature (base64 PNG), terms_version? }
     * Saves the e-signature for a booking — required on every booking,
     * regardless of amount.
     * Returns ok=true on success.
     */
    public function reservation_sign()
    {
        $raw = $this->_read_json();
        if (!$raw) return $this->_error('Invalid JSON body', 400);
        $bookingId = trim((string)($raw['booking_id'] ?? ''));
        $signature = (string)($raw['signature'] ?? '');
        $terms     = trim((string)($raw['terms_version'] ?? 'v1'));
        if ($bookingId === '' || $signature === '') {
            return $this->_error('booking_id and signature are required', 422);
        }
        $row = $this->db->get_where('kfb_bookings', ['booking_id' => $bookingId])->row_array();
        if (!$row) return $this->_error('Booking not found', 404);
        $ok = $this->Booking_model->save_signature($bookingId, $signature, $terms);
        if (!$ok) return $this->_error('Could not save signature', 500);
        $this->_json(['success' => TRUE, 'booking_id' => $bookingId]);
    }

    /**
     * POST /api/customers/register
     * Body: { email, password, first_name, last_name, phone? }
     * Promotes a guest checkout to a real account. If the email already
     * exists, sets/updates the password on the existing customer.
     */
    public function customer_register()
    {
        $raw = $this->_read_json();
        if (!$raw) return $this->_error('Invalid JSON body', 400);
        $email    = strtolower(trim((string)($raw['email'] ?? '')));
        $password = (string)($raw['password'] ?? '');
        if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return $this->_error('Valid email is required', 422);
        }
        if (strlen($password) < 6) {
            return $this->_error('Password must be at least 6 characters', 422);
        }
        $existing = $this->Customer_model->get_by_email($email);
        if ($existing && empty($existing['password_hash'])) {
            // Promote guest → account
            $this->Customer_model->set_password($existing['id'], $password);
            $this->_json(['success' => TRUE, 'customer_id' => (int)$existing['id'], 'promoted' => TRUE]);
        } elseif ($existing) {
            $this->_error('Account already exists for this email', 409);
        } else {
            // Create new
            $id = $this->db->insert('kfb_customers', [
                'email'         => $email,
                'password_hash' => password_hash($password, PASSWORD_BCRYPT),
                'first_name'    => $raw['first_name'] ?? '',
                'last_name'     => $raw['last_name']  ?? '',
                'phone'         => $raw['phone']      ?? NULL,
                'status'        => 'active',
                'created_at'    => date('Y-m-d H:i:s'),
            ]) ? (int)$this->db->insert_id() : 0;
            if (!$id) return $this->_error('Could not create account', 500);
            $this->_json(['success' => TRUE, 'customer_id' => $id, 'promoted' => FALSE]);
        }
    }

    // ----------------- helpers -----------------

    protected function _read_json()
    {
        $raw = $this->input->raw_input_stream;
        if (!$raw) $raw = file_get_contents('php://input');
        $data = json_decode($raw, TRUE);
        return is_array($data) ? $data : NULL;
    }

    protected function _set_cors_headers()
    {
        $origin = isset($_SERVER['HTTP_ORIGIN']) ? $_SERVER['HTTP_ORIGIN'] : '*';
        if (in_array('*', $this->allowed_origins, TRUE)) {
            header('Access-Control-Allow-Origin: *');
        } elseif (in_array($origin, $this->allowed_origins, TRUE)) {
            header('Access-Control-Allow-Origin: ' . $origin);
        }
        header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type, Authorization');
        header('Access-Control-Max-Age: 86400');
        header('Content-Type: application/json; charset=utf-8');

        if ($this->input->method() === 'options') {
            header('HTTP/1.1 204 No Content');
            exit;
        }
    }

    protected function _json($data, $code = 200)
    {
        $this->output
            ->set_status_header($code)
            ->set_content_type('application/json', 'utf-8')
            ->set_output(json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
    }

    protected function _error($message, $code = 400, $extra = [])
    {
        $this->_json(array_merge(['success' => FALSE, 'error' => $message], $extra), $code);
    }
}
